package ma.adnane.ticketmatch.enums;

public enum Statut {
    ACTIVE , DESACTIVE
}
