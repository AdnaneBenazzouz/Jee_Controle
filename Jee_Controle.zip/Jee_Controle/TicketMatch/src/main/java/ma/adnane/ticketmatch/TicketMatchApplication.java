package ma.adnane.ticketmatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketMatchApplication {

    public static void main(String[] args) {
        SpringApplication.run(TicketMatchApplication.class, args);
    }

}
