package ma.adnane.ticketmatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketMatchApplicationTests {

    @Test
    void contextLoads() {
    }

}
